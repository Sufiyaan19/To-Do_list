function addNumbers(a,b){
    return a+b
}

function subNumbers(a,b){
    return a-b
}

module.exports = {addNumbers,subNumbers}