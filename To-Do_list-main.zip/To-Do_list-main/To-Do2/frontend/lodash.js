const lodash = require('lodash')

const numbers = [1,10,2,9,3,8,4,7,5,6]
const max = lodash.max(numbers)
const min = lodash.min(numbers)

export {max,min}
